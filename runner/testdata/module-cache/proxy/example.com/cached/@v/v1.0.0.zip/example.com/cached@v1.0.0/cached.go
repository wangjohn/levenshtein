// Package cached is a dependency the module-cache self-test downloads from a
// file proxy and then modifies in the module cache.
package cached

// Value is what the consumer fixture's test expects.
func Value() int { return 42 }
